import json
from web3 import Web3

class RealEstateAgency:
    def __init__(self):
        self.users = {}
        self.properties = []
        self.ads = []
        self.transactions = []

        # Подключение к локальной сети Ethereum (например, Ganache)
        self.web3 = Web3(Web3.HTTPProvider('http://127.0.0.1:7545'))

        # Загрузка ABI и адреса контракта из файла JSON
        with open('build/contracts/RealEstateAgency.json', encoding='utf-8') as f:
            contract_data = json.load(f)
            contract_abi = contract_data['abi']
            contract_address = contract_data['networks']['5777']['address']

        print(f"Contract address: {contract_address}")

        # Получение экземпляра контракта
        self.contract = self.web3.eth.contract(address=contract_address, abi=contract_abi)

        print(f"Contract functions: {self.contract.functions}")

    def authorize(self, public_key, password):
        try:
            print(f"Calling authorize with publicKey: {public_key}, password: {password}")
            authorized = self.contract.functions.authorize(public_key, password).call()
            return authorized
        except Exception as e:
            print(f"Error calling authorize: {e}")
            return False

    def register(self, public_key, password):
        try:
            tx_hash = self.contract.functions.register(public_key, password).transact({'from': public_key})
            self.web3.eth.wait_for_transaction_receipt(tx_hash)
            self.users[public_key] = {'password': password}
            return "Регистрация успешна"
        except Exception as e:
            print(f"Error during registration: {e}")
            return "Ошибка регистрации"

    def create_property(self, user, property_details):
        try:
            tx_hash = self.contract.functions.createProperty(user, json.dumps(property_details)).transact({'from': user})
            self.web3.eth.wait_for_transaction_receipt(tx_hash)
            self.properties.append(property_details)
            return "Запись о недвижимости успешно создана"
        except Exception as e:
            print(f"Error creating property: {e}")
            return "Ошибка создания записи о недвижимости"

    def create_ad(self, user, ad_details):
        try:
            tx_hash = self.contract.functions.createAd(user, json.dumps(ad_details)).transact({'from': user})
            self.web3.eth.wait_for_transaction_receipt(tx_hash)
            self.ads.append(ad_details)
            return "Объявление успешно создано"
        except Exception as e:
            print(f"Error creating ad: {e}")
            return "Ошибка создания объявления"

    def change_property_status(self, user, property_id, new_status):
        try:
            tx_hash = self.contract.functions.changePropertyStatus(user, property_id, new_status).transact({'from': user})
            self.web3.eth.wait_for_transaction_receipt(tx_hash)
            for property in self.properties:
                if property['id'] == property_id:
                    property['status'] = new_status
                    return "Статус недвижимости успешно изменен"
            return "Недвижимость не найдена"
        except Exception as e:
            print(f"Error changing property status: {e}")
            return "Ошибка изменения статуса недвижимости"

    def change_ad_status(self, user, ad_id, new_status):
        try:
            tx_hash = self.contract.functions.changeAdStatus(user, ad_id, new_status).transact({'from': user})
            self.web3.eth.wait_for_transaction_receipt(tx_hash)
            for ad in self.ads:
                if ad['id'] == ad_id:
                    ad['status'] = new_status
                    return "Статус объявления успешно изменен"
            return "Объявление не найдено"
        except Exception as e:
            print(f"Error changing ad status: {e}")
            return "Ошибка изменения статуса объявления"

    def buy_property(self, user, property_id):
        try:
            print(f"Calling buyProperty with user: {user}, property_id: {property_id}")
            tx_hash = self.contract.functions.buyProperty(user, property_id).transact({'from': user})
            tx_receipt = self.web3.eth.wait_for_transaction_receipt(tx_hash)
            return "Недвижимость успешно куплена"
        except Exception as e:
            print(f"Error buying property: {e}")
            return "Ошибка покупки недвижимости"

    def withdraw_funds(self, user, amount):
        try:
            return "Средства успешно выведены"
        except Exception as e:
            print(f"Error withdrawing funds: {e}")
            return "Ошибка вывода средств"

    def get_info(self, info_type):
        try:
            if info_type == 'properties':
                return self.properties
            elif info_type == 'ads':
                return self.ads
            elif info_type == 'transactions':
                return self.transactions
            else:
                return "Неизвестный тип информации"
        except Exception as e:
            print(f"Error getting info: {e}")
            return "Ошибка получения информации"

    def handle_errors(self, error):
        return f"Ошибка: {error}"

# Пример использования
agency = RealEstateAgency()
print(agency.register('0x0B978eB0C3A1fa32AdEa65fd610f890D7F17c283', 'SecureP@ssw0rd'))
print(agency.create_property('0x0B978eB0C3A1fa32AdEa65fd610f890D7F17c283', {'id': 1, 'name': 'Apartment', 'status': 'available'}))
print(agency.create_ad('0x0B978eB0C3A1fa32AdEa65fd610f890D7F17c283', {'id': 1, 'property_id': 1, 'status': 'active'}))
print(agency.change_property_status('0x0B978eB0C3A1fa32AdEa65fd610f890D7F17c283', 1, 'sold'))
print(agency.change_ad_status('0x0B978eB0C3A1fa32AdEa65fd610f890D7F17c283', 1, 'inactive'))
print(agency.buy_property('0x0B978eB0C3A1fa32AdEa65fd610f890D7F17c283', 1))
print(agency.get_info('properties'))
print(agency.get_info('ads'))
print(agency.get_info('transactions'))
print(agency.authorize('0x0B978eB0C3A1fa32AdEa65fd610f890D7F17c283', 'SecureP@ssw0rd'))
