const RealEstateAgency = artifacts.require("RealEstateAgency");

module.exports = function(deployer) {
  deployer.deploy(RealEstateAgency);
};
